# Example preprocessing script.
# library(ProjectTemplate); load.project(list(munging=FALSE)) # use to debug munging file


v <- list()
v$items <- c("A1", "A2", "A3", "A4", "A5", "C1", "C2", "C3", "C4", "C5", 
             "E1", "E2", "E3", "E4", "E5", "N1", "N2", "N3", "N4", "N5", "O1", 
             "O2", "O3", "O4", "O5")


rcases$missingcount <- apply(rcases[,v$items], 1, 
                             function(X) sum(is.na(X)))
table(rcases$missingcount)

rcases <- rcases[ rcases$missingcount == 0, ]

rcases$uniquecount <- 
    apply(rcases[,v$items], 1, 
                             function(X) length(unique(X)))
table(rcases$uniquecount)

ccases <- rcases[ rcases$uniquecount != 1, ]

set.seed(23434324)
ccases$sample <- 
    sample(c("confirmatory", "exploratory"), nrow(ccases), replace = TRUE)

split_cases <- split(ccases, ccases$sample)

ecases <- split_cases$exploratory

