# Example Unit Testing Script

expect_that(1, equals(1))
