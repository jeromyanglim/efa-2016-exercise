# Example preprocessing script.
# library(ProjectTemplate); load.project(list(munging=FALSE)) # use to debug munging file

v <- list()
v$bfi_items <- meta.bfi$name
v$bfi_scales <- unique(meta.bfi$scale)

# * Clean data.
# COMPUTE missing_count=NMISS(A1 to O5).
# EXECUTE.
rbfi$missing_count <- apply(rbfi[,v$bfi_items], 1, function(X) sum(is.na(X)))

# freq missing_count.
table(rbfi$missing_count)


# * remove cases with many missing items.
# FILTER OFF.
# USE ALL.
# SELECT IF (missing_count < 3).
# EXECUTE.
# * save as "bfi-unique-2.sav".
cbfi <- rbfi[ rbfi$missing_count < 3, ]

# freq missing_count.
# table(cbfi$missing_count)


# * problematic cases based on mahalanobis.
# REGRESSION
#   /MISSING MEANSUBSTITUTION
#   /STATISTICS COEFF OUTS R ANOVA
#   /CRITERIA=PIN(.05) POUT(.10)
#   /NOORIGIN 
#   /DEPENDENT id
#   /METHOD=ENTER A1 A2 A3 A4 A5 C1 C2 C3 C4 C5 E1 E2 E3 E4 E5 N1 N2 N3 N4 N5 O1 O2 O3 O4 O5
#   /SAVE MAHAL(mahal_items).
cbfi$mahal_items <- mahalanobis(cbfi[ , v$bfi_items], 
                                center = sapply(cbfi[ , v$bfi_items], mean, na.rm = TRUE),
                                cov = cov(cbfi[ , v$bfi_items], use = "complete"))


# FREQUENCIES VARIABLES=mahal_items  /HISTOGRAM  /ORDER=ANALYSIS.
# hist(cbfi$mahal_items)

# USE ALL.
# COMPUTE filter_$=(mahal_items > 70 ).
# VARIABLE LABELS filter_$ 'mahal_items > 70  (FILTER)'.
# VALUE LABELS filter_$ 0 'Not Selected' 1 'Selected'.
# FORMATS filter_$ (f1.0).
# FILTER BY filter_$.
# EXECUTE.

# SUMMARIZE
#   /TABLES= A1 A2 A3 A4 A5 C1 C2 C3 C4 C5 E1 E2 E3 E4 E5 N1 N2 N3 N4 N5 O1 O2 O3 O4 O5
#   /FORMAT=VALIDLIST NOCASENUM TOTAL LIMIT=100
#   /TITLE='Case Summaries'
#   /MISSING=VARIABLE
#   /CELLS=NONE.
cbfi[ cbfi$mahal_items > 70, v$bfi_items]

# USE ALL.

# * Check that raw data ranges from 1 to 6.
# DESCRIPTIVES VARIABLES=A1 A2 A3 A4 A5 C1 C2 C3 C4 C5 E1 E2 E3 E4 E5 N1 N2 N3 N4 N5 O1 O2 O3 O4 O5
#   /STATISTICS=MIN MAX.
sapply(cbfi[ v$bfi_items], range, na.rm = TRUE)

# * to run this on other computers adjust the path.
# MVA VARIABLES=A1 A2 A3 A4 A5 C1 C2 C3 C4 C5 E1 E2 E3 E4 E5 N1 N2 N3 N4 N5 O1 O2 O3 O4 O5 gender 
#     education age missing_count mahal_items filter_$ 
#   /ID=id
#   /EM A1 A2 A3 A4 A5 C1 C2 C3 C4 C5 E1 E2 E3 E4 E5 N1 N2 N3 N4 N5 O1 O2 O3 O4 O5 WITH A1 A2 A3 A4 
#     A5 C1 C2 C3 C4 C5 E1 E2 E3 E4 E5 N1 N2 N3 N4 N5 O1 O2 O3 O4 O5(TOLERANCE=0.001 CONVERGENCE=0.0001 
#     ITERATIONS=25 OUTFILE='/Users/jeromy/teaching/org-research-methods/2013/content/05 Cluster and '+
#     'factor analysis/exercises/data/bfi-unique-3.sav').

library(Amelia)
set.seed(1234)
temp <- Amelia::amelia(cbfi[,v$bfi_items], m = 1, boot.type = "none")
# head(temp$imputations$imp1)
# head(cbfi[,v$bfi_items])
cbfi[,v$bfi_items] <- temp$imputations$imp1


# * switch to bfi-unique-3.sav.

# * round items to nearest integer.
# DO REPEAT R=A1 to O5.
# COMPUTE R = rnd(R).
# END REPEAT.
# EXECUTE.
cbfi[,v$bfi_items] <- sapply(cbfi[,v$bfi_items], round)

# * check that rounding worked.
# freq A1.
# table(cbfi$A1)


# * split data files into 2. 
# USE ALL.
# do if $casenum=1.
# compute #s_$_1=1236.
# compute #s_$_2=2472.
# end if.
# do if  #s_$_2 > 0.
# compute filter_$=uniform(1)* #s_$_2 < #s_$_1.
# compute #s_$_1=#s_$_1 - filter_$.
# compute #s_$_2=#s_$_2 - 1.
# else.
# compute filter_$=0.
# end if.
# VARIABLE LABELS filter_$ '1236 from the first 2472 cases (SAMPLE)'.
# FORMATS filter_$ (f1.0).Î
# FILTER  BY filter_$.
# EXECUTE.
# 
# * renamed filter_$ into dataset and saved two new versions with just exploratory or confirmatory data.
# * I coded 0 = exploratory and 1 = confirmatory and run the code below on the two new datsets.
# FILTER OFF.
# USE ALL.
# SELECT IF (dataset=1).
# EXECUTE.
# 
# FILTER OFF.
# USE ALL.
# SELECT IF (dataset=0).
# EXECUTE.

cbfi$sample <- sample( rep(c("exploratory", "confirmatory"),  nrow(cbfi)/2))
ecbfi <- cbfi[ cbfi$sample == "exploratory", ]
ccbfi <- cbfi[ cbfi$sample == "confirmatory", ]



# * score tests.
# * create copy of variables where items are reversed if necessary.
# DO REPEAT x = A1  A2 A3 A4 A5 C1 C2 C3 C4 C5 E1 E2 E3 E4 E5 N1 N2 N3 N4 N5 O1 O2 O3 O4 O5 /
#      xReversed = A1r  A2r  A3r  A4r  A5r  C1r  C2r  C3r  C4r  C5r  E1r  E2r  E3r  E4r  E5r  N1r  N2r  N3r  N4r  N5r  O1r  O2r  O3r  O4r  O5r   /
#   xMultiplier =-1  1  1  1  1  1  1  1  -1  -1  -1  -1  1  1  1  1  1  1  1  1  1  -1  1  1  -1.
# compute xReversed = x.
# if (xMultiplier = -1) xReversed = 6 - x.
# END REPEAT.
# EXECUTE .
# score tests
# * check that reversal worked.
# * a1r should be reversed; a2r not reversed.
# crosstabs a1 by a1r.
# crosstabs a2 by a2r.
# note in R you don't need to reverse items when scoring; the function does it for you.

create_scoring_key <- function(items, scales, reverse) {
    unique_scales <- unique(scales)
    key <- sapply(seq(unique_scales), 
                  function(X) ifelse(scales == unique_scales[X], reverse, 0))
    key <- data.frame(key)
    names(key) <- unique_scales
    row.names(key) <- items
    key
}

score_test <- function(meta_data, case_data, subscale_name='subscale_name', id='id', reverse='reverse') {
    scoring_key <- create_scoring_key(meta_data[, id], 
                                      meta_data[ ,subscale_name],  
                                      meta_data[ ,reverse])
    scored <- scoreItems(scoring_key, case_data[,rownames(scoring_key)])
    scored$key <- scoring_key
    scored
}



scored <- list()
scored<- score_test(meta.bfi, ecbfi, subscale_name = "scale", id = "name", reverse="reverse")

# compute neuroticism= mean(n1r, n2r, n3r, n4r, n5r).
# compute extraversion = mean(e1r, e2r, e4r, e5r).
# compute openness = mean(o1r, o2r, o3r, o5r).
# compute agreeableness = mean(a1r, a2r, a3r, a4r, a5r).
# compute conscientiousness = mean(c1r, c2r, c3r, c4r, c5r).
# execute.
ecbfi[,colnames(scored$scores)] <- scored$scores

